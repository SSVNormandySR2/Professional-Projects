import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testMod10 
{

	public static boolean IsValidMod10Number(String number)
	{
		int[] numberArray = new int[number.length()];
		boolean checkBit = false;
		int sumTotal = 0;
		
		for(int i = 0; i < number.length(); i++)
		{
			numberArray[i] = Math.abs(48 - ((int) number.charAt(i)));
		}
		
		for(int index = numberArray.length-1; index > -1; index--)
		{
			if(checkBit)
			{
				numberArray[index] *= 2;
				if(numberArray[index] > 9)
				{
					numberArray[index] -= 9;
				}
			}
			sumTotal += numberArray[index];
			checkBit = !checkBit;
		}
		
		return sumTotal % 10 == 0;
	}
	
	@Test
	void Path1() 
	{
		assertEquals(true, IsValidMod10Number(""));
	}

	@Test
	void Path3()
	{
		assertEquals(false, IsValidMod10Number("5"));
	}
	
	@Test
	void Path4()
	{
		assertEquals(true, IsValidMod10Number("42"));
	}
	
	@Test
	void Path5()
	{
		assertEquals(false, IsValidMod10Number("84"));
	}
}
