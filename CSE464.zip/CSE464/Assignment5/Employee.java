/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class extends a person with an ID
 */
public class Employee extends Person
{
	private int empID; //Employee ID
	
	/*
	 * This constructor initializes data members
	 */
	public Employee(String f, String l, String m, int e)
	{
		super(f, l, m); //Call parent constructor
		empID = e; //Assign employee ID
	}
	
	/*
	 * This method returns the first name
	 */
	public String getFirst() 
	{
		return super.getFirst(); //Return first name
	}

	/*
	 * This method returns the last name
	 */
	public String getLast() 
	{
		return super.getLast(); //Return last name
	}

	/*
	 * This method returns the middle name
	 */
	public String getMiddle() 
	{
		return super.getMiddle(); //Return middle name
	}
	
	/*
	 * This method returns the employee ID
	 */
	public int getID()
	{
		return empID; //Returns the employee ID
	}
}
