/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class defines a person object of names
 */
public class Person 
{
	protected String first; //First name
	protected String last; //Last name
	protected String middle; //Middle name
	
	/*
	 * This constructor initializes data members
	 */
	public Person(String f, String l, String m)
	{
		first = f; //Assign first
		last = l; //Assign last
		middle = m; //Assign middle
	}
	
	/*
	 * This method returns the first name
	 */
	public String getFirst() 
	{
		return first; //Return first name
	}

	/*
	 * This method returns the last name
	 */
	public String getLast() 
	{
		return last; //Return last name
	}

	/*
	 * This method returns the middle name
	 */
	public String getMiddle() 
	{
		return middle; //Return middle name
	}
}
