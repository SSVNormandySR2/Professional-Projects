/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class represents a dial error
 */
public class DialErrorException extends Exception 
{
	/*
	 * This constructor initializes the exception
	 */
	public DialErrorException() 
	{
		super(); //Call exception constructor
	}
	
	/*
	 * This method triggers an exception
	 */
	public DialErrorException(String error) 
	{
		super(error); //Call parent exception
	}
}