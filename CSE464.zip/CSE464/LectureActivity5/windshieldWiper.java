/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class represents the integrated wiper system
 */
public class windshieldWiper 
{
	private lever l; //Lever for lever position
	private dial d; //Dial for dial position
	private wiper w; //Wiper for speed
	
	/*
	 * This constructor initializes the object states
	 */
	public windshieldWiper(int wiperSpeed, String leverPosition, int dialPosition) 
	{
		l = new lever(leverPosition); //Initialize lever state
		d = new dial(dialPosition); //Initialize dial state
		w = new wiper(wiperSpeed); //Initialize wiper state
	}
	
	/*
	 * This method returns the current wiper speed
	 */
	public int getWiperSpeed() 
	{
		return w.getWiperSpeed(); //Return wiper speed
	}
	
	/*
	 * This method changes the wiper speed
	 */
	public void setWiperSpeed(int wiperSpeed) 
	{
		w.setWiperSpeed(wiperSpeed); //Set wiper speed
	}
	
	/*
	 * This method returns the current lever position
	 */
	public String getLeverPosition() 
	{
		return l.getLeverPosition(); //Return lever position
	}
	
	/*
	 * This method changes the lever position
	 */
	public void setLeverPosition(String leverPosition) 
	{
		l.setLeverPosition(leverPosition); //Set lever position
	}
	
	/*
	 * This method returns the current dial position
	 */
	public int getDialPosition() 
	{
		return d.getDialPosition(); //Return dial position
	}
	
	/*
	 * This method changes the dial position
	 */
	public void setDialPosition(int dialPosition) 
	{
		d.setDialPosition(dialPosition); //Set dial position
	}
	
	/*
	 * This method simulates increased lever position
	 */
	public void senseLeverUp() throws LeverErrorException 
	{
		if((l.getLeverPosition()).equals("OFF")) //Off case
		{
			l.setLeverPosition("INT"); //Set lever to intermediate
			switch(d.getDialPosition()) //Switch on dial position
			{
				case 1: //Dial position is 1
				{
					w.setWiperSpeed(6); //Set wiper speed to 6
					break; //Do not fall through
				}
				case 2: //Dial position is 2
				{
					w.setWiperSpeed(12); //Set wiper speed to 12
					break; //Do not fall through
				}
				case 3: //Dial position is 3
				{
					w.setWiperSpeed(20); //Set wiper speed to 20
					break; //Do not fall through
				}
			}
		}
		else if((l.getLeverPosition()).equals("INT")) //Intermediate case
		{
			l.setLeverPosition("LOW"); //Set lever position to Low
			w.setWiperSpeed(30); //Set wiper speed to 30
		}
		else if((l.getLeverPosition()).equals("LOW")) //Low case
		{
			l.setLeverPosition("HIGH"); //Set lever position to High
			w.setWiperSpeed(60); //Set wiper speed to 60
		}
		else if((l.getLeverPosition()).equals("HIGH")) //High case
		{
			System.out.println("ERROR: leverPosition already at HIGH."); //Print error message
			throw new LeverErrorException(); //Throw lever exception
		}
	}
	
	/*
	 * This method simulates decreased lever position
	 */
	public void senseLeverDown() throws LeverErrorException 
	{
		if((l.getLeverPosition()).equals("OFF")) //Off case
		{
			System.out.println("ERROR: leverPosition already at OFF."); //Print error message
			throw new LeverErrorException(); //Throw lever exception
		}
		else if((l.getLeverPosition()).equals("INT")) //Intermediate case
		{
			l.setLeverPosition("OFF"); //Set lever position to Off
			w.setWiperSpeed(0); //Set wiper speed to 0
		}
		else if((l.getLeverPosition()).equals("LOW")) //Low case
		{
			l.setLeverPosition("INT"); //Set lever position to Intermediate
			switch(d.getDialPosition()) //Switch on dial position
			{
				case 1: //Dial position is 1
				{
					w.setWiperSpeed(6); //Set wiper speed to 6
					break; //Do not fall through
				}
				case 2: //Dial position is 2
				{
					w.setWiperSpeed(12); //Set wiper speed to 12
					break; //Do not fall through
				}
				case 3: //Dial position is 3
				{
					w.setWiperSpeed(20); //Set wiper speed to 20
					break; //Do not fall through
				}
			}
		}
		else if((l.getLeverPosition()).equals("HIGH")) //High case
		{
			l.setLeverPosition("LOW"); //Set lever position to Low
			w.setWiperSpeed(30); //Set wiper speed to 30
		}
	}
	
	/*
	 * This method simulates increased dial position
	 */
	public void senseDialUp() throws DialErrorException 
	{
		if(d.getDialPosition() == 3) //Dial position is 3 case
		{
			System.out.println("Already on highest setting"); //Print error message
			throw new DialErrorException(); //Throw dial exception
		}
		else //Dial position is 1-2 case
		{
			d.setDialPosition(d.getDialPosition()+1); //Increase dial position by 1
			if((l.getLeverPosition()).equals("INT")) //Intermediate case
			{
				switch(d.getDialPosition()) //Switch on dial position
				{
					case 1: //Dial position is 1
					{
						w.setWiperSpeed(6); //Set wiper speed to 6
						break; //Do not fall through
					}

					case 2: //Dial position is 2
					{
						w.setWiperSpeed(12); //Set wiper speed to 12
						break; //Do not fall through
					}
					case 3: //Dial position is 3
					{
						w.setWiperSpeed(20); //Set wiper speed to 20
						break; //Do not fall through
					}
				}
			}
		}
	}
	
	/*
	 * This method simulates decreased dial position
	 */
	public void senseDialDown() throws DialErrorException 
	{
		if(d.getDialPosition() == 1) //Dial position is 1 case
		{
			System.out.println("Already on lowest setting"); //Print error message
			throw new DialErrorException(); //Throw dial exception
		}
		else //Dial position is 3-2 case
		{
			d.setDialPosition(d.getDialPosition()-1); //Decrease dial position by 1
			if((l.getLeverPosition()).equals("INT")) //Intermediate case
			{
				switch(d.getDialPosition()) //Switch on dial position
				{
					case 1: //Dial position is 1
					{
						w.setWiperSpeed(6); //Set wiper speed to 6
						break; //Do not fall through
					}
					case 2: //Dial position is 2
					{
						w.setWiperSpeed(12); //Set wiper speed to 12
						break; //Do not fall through
					}
					case 3: //Dial position is 3
					{
						w.setWiperSpeed(20); //Set wiper speed to 20
						break; //Do not fall through
					}
				}
			}
		}
	}
}