/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class represents the wiper of the wiper system
 */
public class wiper 
{
	private int wiperSpeed; //Speed state variable

	/*
	 * This constructor initializes the speed state
	 */
	public wiper(int wiperSpeed) 
	{
		this.wiperSpeed = wiperSpeed; //Set speed state
	}
	
	/*
	 * This method returns the current speed state
	 */
	public int getWiperSpeed() 
	{
		return wiperSpeed; //Return speed state
	}

	/*
	 * This method changes the speed state
	 */
	public void setWiperSpeed(int wiperSpeed) 
	{
		this.wiperSpeed = wiperSpeed; //Set speed state
	}
}