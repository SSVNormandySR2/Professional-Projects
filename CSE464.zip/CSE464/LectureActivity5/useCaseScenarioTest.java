/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;


public class useCaseScenarioTest
{
	private static windshieldWiper wiperSystem; //Define wiper system to test
	
	@BeforeClass
	public static void setUp()
	{
		wiperSystem = new windshieldWiper(0, "OFF", 1); //Set preconditions
	}
	
	@Test
	public void useCaseEvent01()
	{
		try
		{
			wiperSystem.senseLeverUp(); //Move lever up
			assertEquals(6, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(1, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch (LeverErrorException e) //Exception case
		{
			fail("Lever error not expected"); //Fail test
		}
	}
	
	@Test
	public void useCaseEvent03()
	{
		try
		{
			wiperSystem.senseDialUp(); //Move dial up
			assertEquals(12, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(2, wiperSystem.getDialPosition()); //Verify dial position
		} 
		catch (DialErrorException e) //Exception case
		{
			fail("Dial error not expected"); //Fail test
		}
	}
	
	@Test
	public void useCaseEvent05()
	{
		try
		{
			wiperSystem.senseDialUp(); //Move dial up
			assertEquals(20, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch (DialErrorException e) //Exception case
		{
			fail("Dial error not expected"); //Fail test
		}
	}
	
	@Test
	public void useCaseEvent07()
	{
		try
		{
			wiperSystem.senseLeverUp(); //Move lever up
			assertEquals(30, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("LOW", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch (LeverErrorException e) //Exception case
		{
			fail("Lever error not expected"); //Fail test
		}
	}
	
	@Test
	public void useCaseEvent09()
	{
		try
		{
			wiperSystem.senseLeverDown(); //Move lever down
			assertEquals(20, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch (LeverErrorException e) //Exception case
		{
			fail("Lever error not expected"); //Fail test
		}
	}
	
	@Test
	public void useCaseEvent11()
	{
		try
		{
			wiperSystem.senseLeverDown(); //Move lever down
			assertEquals(0, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("OFF", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch (LeverErrorException e) //Exception case
		{
			fail("Lever error not expected"); //Fail test
		}
	}
	
	@AfterClass
	public static void tearDown()
	{
		wiperSystem = new windshieldWiper(0, "OFF", 3); //Set postconditions
	}
}
