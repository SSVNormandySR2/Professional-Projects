#Import needed libraries
library(dplyr)
library(tidyverse)
library(plotly)
library(ggplot2)

#Import NHL Teams data set
getwd()
df = read.csv("Teams.csv")

attach(df)
df
df = df %>% filter(G == 82 & lgID == "NHL") %>%
  select(year, name, rank, W, L, OTL, Pts, GF, GA, playoff)
df
#Cleaning - Select certain columns needed and refine range for sample
df = df %>% filter(G == 82 & lgID == "NHL") %>%
  select(year, name, rank, W, L, OTL, Pts, GF, GA, playoff)
setorder(df, year, -Pts)
for (i in 1995:2011)
{
  df$rank[df$year == i] = 1:length(df$year[df$year == i]) 
}
df$playoff = recode_factor(df$playoff, "SC" = 1, "F" = 2, "CF" = 3, "CSF" = 4, "CQF" = 5, .default=6)

df

#EDA - Avg goals for and against per season
#Data Visualization - Start modeling for possible influential factors on rank or playoff
#Conclusions on the models

