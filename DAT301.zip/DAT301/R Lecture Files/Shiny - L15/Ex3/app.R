

library(shiny)
library(datasets)

mpgData = mtcars
mpgData$am = factor(mpgData$am, labels=c("Automatic", "Manual"))

ui = fluidPage(
  titlePanel("mtcars dataset"),
  sidebarLayout(
    sidebarPanel(
      selectInput("variable", "Variable:",
                  c("Cylinders" = "cyl",
                    "Transmission" = "am",
                    "Gears" = "gear")),
      checkboxInput("outliers", "Show Outliers", TRUE)
    ),
    mainPanel(
      h3(textOutput("caption")),
      plotOutput("mpgPlot")
    )
  )
)

server = function(input, output)
{
  formulaText = reactive({
    paste("mpg~", input$variable)
  })
  output$caption = renderText({
    formulaText()
  })
  output$mpgPlot = renderPlot({
    boxplot(as.factor(formulaText()),
            data=mpgData,
            outline=input$outliers,
            col="#75AADB", pch=19)
  })
}

shinyApp(ui=ui, server=server)
