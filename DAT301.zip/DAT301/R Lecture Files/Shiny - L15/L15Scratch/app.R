#

library(shiny)

ui = fluidPage(
  titlePanel("title panel"),
  
  
  sidebarLayout(position="right", #left by default
                sidebarPanel("sidebar panel"),
                mainPanel("main panel")
                ) 
)

server = function(input, output)
{
  
}

shinyApp(ui=ui, server=server)