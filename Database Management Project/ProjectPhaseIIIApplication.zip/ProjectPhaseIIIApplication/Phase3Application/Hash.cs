﻿/*
 * Vyom Khare
 * Vincent Latona
 */

using System;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace Phase3Application
{
    public class Hash
    {
        /*
         * This function computes a hash for a given input string
         */
        public static string hash(string input)
        {
            string hashed = ""; //Create hash return variable
            using (SHA256 shaHash = SHA256.Create()) //Hashing scope
            {
                byte[] bytes = shaHash.ComputeHash(Encoding.UTF8.GetBytes(input)); //Create hashed bytes
                hashed = BitConverter.ToString(bytes).Replace("-", ""); //Convert bytes to string
            }
            hashed = hashed.ToLower(); //Convert to lowercase
            return hashed; //Return computed hash
        }
    }
}