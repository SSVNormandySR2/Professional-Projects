package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.paint.*;

public class Shapes extends Application
{
       public void start(Stage primaryStage)
         {

             Rectangle r1 = new Rectangle(0,0,200, 200);
             r1.setFill(Color.BLUE);
             Rectangle r2 = new Rectangle(200,200,100, 100);
             r2.setFill(Color.BLUE);;

             Rectangle r3 = new Rectangle(300,300,50, 50);
             r3.setFill(Color.BLUE);
             Rectangle r4 = new Rectangle(350,350,25, 25);
             r4.setFill(Color.BLUE);
             Rectangle r5 = new Rectangle(375,375, 25,25);
             r5.setFill(Color.BLUE);

             Arc  arc1 = new Arc(300, 100, 100, 100, 0, 90);
             arc1.setFill(Color.RED);
             arc1.setType(ArcType.ROUND);
             Arc arc2 = new Arc(300, 100, 100, 100, 180,90);
             arc2.setFill(Color.RED);
             arc2.setType(ArcType.ROUND);

             Arc arc3 = new Arc(100, 300, 100, 100, 0,90);
             arc3.setFill(Color.RED);
             arc3.setType(ArcType.ROUND);
             Arc arc4 = new Arc(100,300, 100, 100, 180,90);
             arc4.setFill(Color.RED);
             arc4.setType(ArcType.ROUND);
                // Create a scene and place it in the stage
             Pane pane = new Pane();
             pane.getChildren().addAll(r1, r2, r3, r4, r5, arc1, arc2, arc3, arc4);

             Scene scene = new Scene(pane, 400, 400);
             primaryStage.setTitle("JavaFX GUI shapes Demo"); // Set the stage title
             primaryStage.setScene(scene); // Place the scene in the stage
             primaryStage.show(); // Display the stage
         }

       public static void main(String[] args) {
              System.out.println("launch application");
              Application.launch(args);
       }
}