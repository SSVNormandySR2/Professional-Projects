package application;

//This Pane allow user to draw fixed sized dots
//see also DotDemo.java

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
//import javafx.scene.shape.Shape;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.Pane;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent; 	//**Need to import

import java.util.ArrayList;

public class DotsPaneTwo extends BorderPane
{
 private final int RADIUS = 6;
 private Label msg;
 private Button undoBtn, eraseBtn;
 private ArrayList<Circle> dotList;
 private Pane topPane;
 private int dotCount;

 public DotsPaneTwo()
 {
	   //Step #1: initialize instance variable and set up layout
	   msg = new Label("Count: "+ dotCount);

	   //place the msg at (10,10) location
	   msg.setLayoutX(10);
	   msg.setLayoutY(10);
	   msg.setTextFill(Color.RED);
	   dotCount = 0;
	   undoBtn = new Button("Undo");
	   eraseBtn = new Button("Erase");

	   dotList = new ArrayList<Circle>();

	   //set up layout
	   topPane = new Pane();
	   topPane.setStyle("-fx-background-color: black;");

	   //put message on topPane
	   topPane.getChildren().add(msg);

	   //create a new horizontal TilePane
	   TilePane bottomPane = new TilePane(Orientation.HORIZONTAL);

	   //set the horizontal gap between buttons
	   bottomPane.setHgap(10.0);
	   bottomPane.getChildren().addAll(undoBtn, eraseBtn);
	   bottomPane.setAlignment(Pos.CENTER);
	   this.setCenter(topPane);
	   this.setBottom(bottomPane);

	   //Step #3:
	   topPane.setOnMousePressed(new DotsHandler());
	   undoBtn.setOnAction(new ButtonHandler());
	   eraseBtn.setOnAction(new ButtonHandler());
	}

	private class DotsHandler implements EventHandler<MouseEvent>
	{
		 public void handle(MouseEvent event)
		 {
			 double x = event.getX();
			 double y = event.getY();
			 Circle circle1 = new Circle(x, y, RADIUS);
			 circle1.setFill(Color.YELLOW);
			 dotList.add(circle1);
			 topPane.getChildren().add(circle1);
			 dotCount++;
			 msg.setText("Count: "+ dotCount);
		 }
	}//end DotsHandler

	private class ButtonHandler implements EventHandler<ActionEvent>
	{
		 public void handle(ActionEvent event)
		 {
			 Object source = event.getSource();
			 if(source == undoBtn && dotList.size() > 0)
			 {
				topPane.getChildren().remove(dotList.size());
				dotCount--;
			 	msg.setText("Count: "+ dotCount);
				dotList.remove(dotList.size()-1);
			 }
			 else if(source == eraseBtn)
			 	{
					dotList.clear();
					topPane.getChildren().clear();
					dotCount = 0;
				 	msg.setText("Count: "+ dotCount);
				 	topPane.getChildren().add(msg);
			 	}
			 	else
			 	{
				}
		 }
	}//end ButtonHandler
}