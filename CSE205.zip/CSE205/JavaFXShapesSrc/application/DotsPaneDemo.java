package application;

//This program draw fixed size yellow dots on screen
//It also show a counter label

import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.event.EventHandler;		//***need to import
import javafx.scene.input.MouseEvent;	//***need to import

class DotsPaneDemo extends StackPane
{
	//GUI components
	private final int RADIUS = 8;
	private Label msg;
	private int dotCount;
	private Pane pane;

	public DotsPaneDemo()
	{
		//step #1: initialize each instance variable and set up layout
		dotCount = 0;
		msg = new Label("cout: " + dotCount);
		msg.setLayoutX(10);	//put msg at (10,10) location
		msg.setLayoutY(10);
		msg.setTextFill(Color.WHITE);
		pane = new Pane();
		pane.setStyle("-fx-background-color: black;");
		pane.getChildren().add(msg);
		this.getChildren().add(pane);

		//Step #3: Register the pane with the mouse handler object
		DotsHandler mouseHandler = new DotsHandler();
		pane.setOnMousePressed(mouseHandler);
	}
	//Step #2: Write a MouseEvent handling class
	private class DotsHandler implements EventHandler<MouseEvent>
	{
		//override the abstract method
		public void handle(MouseEvent e)
		{
			//get the x & y coordinates of the point where we click the mouse
			double x = e.getX();
			double y = e.getY();

			//create a Circle object
			Circle c1 = new Circle(x, y, RADIUS);
			c1.setFill(Color.YELLOW);
			pane.getChildren().add(c1);
			dotCount++;
			msg.setText("count: " + dotCount);
		}
	}
}