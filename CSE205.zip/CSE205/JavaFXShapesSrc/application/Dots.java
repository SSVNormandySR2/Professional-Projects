package application;

//This program demonstrate drawing  multiple dots on screen

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class Dots extends Application
{
  public void start(Stage stage1)
  {
      //DotsPaneDemo gui = new DotsPaneDemo();
      //Pane pane1 = gui.createPane();
      DotsPaneTwo gui = new DotsPaneTwo();
      Scene scene1 = new Scene(gui, 200, 200);
      stage1.setScene(scene1);
      stage1.setTitle("Mouse Example");
      stage1.show();

  }

  public static void main(String[] args)
  {
	     Application.launch(args);
  }
}