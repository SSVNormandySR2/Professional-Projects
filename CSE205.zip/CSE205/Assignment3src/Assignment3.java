
Assignment #: 3
        Name: Vincent Latona
   StudentID: 1216583771
     Lecture: T/Th 1:30 - 2:45pm

1. PUBLIC – Software engineers shall act consistently with the public interest.

--Software engineers who write a program that involves financial information are obligated
to ensure that the information of the customers is safe and secure.

2. CLIENT AND EMPLOYER – Software engineers shall act in a manner that is in the best interests 
of their client and employer consistent with the public interest.

--Programmers that work for Cisco or Microsoft have an obligation to respect the intellectual
property of their employer's. Microsoft workers must maintain the confidentiality of their 
employer's products.

3. PRODUCT – Software engineers shall ensure that their products and related modifications meet 
the highest professional standards possible.

--Programmers must engage in rigorous error-testing for their programs to ensure that their 
product is robust enough for public use.

7. COLLEAGUES – Software engineers shall be fair to and supportive of their colleagues.

--Software engineers must work as a team and aspire towards the same goal. Programmers should not
attempt to undercut each other or steal credit for another programmer's work.

8. SELF – Software engineers shall participate in lifelong learning regarding the practice of 
their profession and shall promote an ethical approach to the practice of the profession.

--Software engineers in the defense industry will eventually come to an ethical dilemma of how
their work may be used. These programmers must abide by their ethics and stick to public interest
of how their work will be used.