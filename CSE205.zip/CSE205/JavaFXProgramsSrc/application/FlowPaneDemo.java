package application;

//This program demonstrates using of FlowPane to set
//up the layout.

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;

import javafx.scene.control.*;		//Button, Label, TextField is inside the pkg

import javafx.scene.layout.FlowPane;//**must import in order to use FlowPane

import javafx.geometry.Insets;

public class FlowPaneDemo extends Application
{
public void start(Stage primaryStage)
{
  // Create a flowpane and set its properties
  FlowPane pane = new FlowPane();

  //An Inset object specifies the size of the border of a pane.
  //The following creates an Insets with the border sizes for top (11),
  //right (12),bottom (13), and left (14) in pixels
  pane.setPadding(new Insets(11, 12, 13, 14));
  pane.setHgap(5);	//set horizontal gap between nodes
  pane.setVgap(5);	//set vertical gap between nodes

  //create 3 nodes
  Button btOK = new Button("Okay");
  Label oneLabel = new Label("First Name:");
  TextField oneTF = new TextField("John Smith");
  oneTF.setPrefColumnCount(15);		//set textfield width

  //Place nodes in the FlowPane
  pane.getChildren().addAll(btOK, oneLabel, oneTF);

  // Create a scene and place it in the stage
  Scene scene = new Scene(pane, 200, 100);
  primaryStage.setTitle("FlowPane Demo"); // Set the stage title
  primaryStage.setScene(scene); // Place the scene in the stage
  primaryStage.show(); // Display the stage
}
public static void main(String[] args)
{
	launch(args);
}
}