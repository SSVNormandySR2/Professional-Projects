package application;

//This program demonstrate using of GridPane class
//GridPane organizes nodes in a grid of columns and rows.
//Each node is placed in the specified column and row index.
//Note: column number comes first and index starts from 0

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;	//***
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.HPos;

public class GridPaneDemo extends Application
{
public void start(Stage primaryStage)
{
  // Create a GridPane object and set its properties
  GridPane pane = new GridPane();
  pane.setAlignment(Pos.CENTER);	//always place the GridPane in the center of scene

  pane.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
  pane.setHgap(5.5);		//set horizontal gap between columns
  pane.setVgap(5.5);		//set vertical gap between rows

  //Create 3 labels
  Label fName = new Label("First Name:");
  Label mInitial = new Label("MI:");
  Label lName = new Label("Last Name:");

  //Create 3 text fields
  TextField fNameField = new TextField();
  TextField mInitField = new TextField();
  TextField lNameField = new TextField();

 	//add fName label at column 0, row 0 and its text field at col 1, row 0
  pane.add(fName, 0, 0);
  pane.add(fNameField, 1, 0);

  //add middle initianl at column 0, row 1 and its text field at col 1, row 1
  pane.add(mInitial, 0, 1);
  pane.add(mInitField , 1, 1);

 //add lName at col 0, row 2 and its text field at col 1, row 2
  pane.add(lName, 0, 2);
  pane.add(lNameField, 1, 2);

  //add button at col 1, row 3. Also place it to
  //the right of the grid horizontally
  Button btAdd = new Button("Add Name");
  pane.add(btAdd, 1, 3);
  GridPane.setHalignment(btAdd, HPos.RIGHT);

  // Create a scene and place it in the stage
  Scene scene = new Scene(pane);
  primaryStage.setTitle("GridPane Demo"); // Set the stage title
  primaryStage.setScene(scene); // Place the scene in the stage
  primaryStage.show(); // Display the stage
}
public static void main(String[] args)
{
launch(args);
}
}