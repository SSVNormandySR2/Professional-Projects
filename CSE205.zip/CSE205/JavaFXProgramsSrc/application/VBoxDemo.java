package application;

//This program demonstrate using of the VBox to set up the layout
//VBox lays out its children in a single vertical column.

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class VBoxDemo extends Application
{
public void start(Stage stage1)
 {
  // create four buttons
  Button button1 = new Button("Button1");
  Button button2 = new Button("Button2");
  Button button3 = new Button("Button3");
  Button button4 = new Button("Button4");

  VBox pane1 = new VBox();

  //set the vertical spacing between the nodes
  pane1.setSpacing(20);

  //set the minimum size of the pane's width & height
  pane1.setMinSize(50,100);

  pane1.getChildren().addAll(button1,button2,button3,button4);

  Scene scene1 = new Scene(pane1);
  stage1.setScene(scene1);
  stage1.show();
}
public static void main(String[] args)
{
	launch(args);
}
}