package application;

//This program demonstate event handling with RadioButton
//It displays three radio buttons which can be selected or
//unselected to change the color of the string

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton; //**Need to import
import javafx.scene.control.ToggleGroup; //**Need to import
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
import javafx.geometry.Insets;
import javafx.event.ActionEvent;	//**Need to import
import javafx.event.EventHandler;	//**Need to import

public class EventHandleRadioButtonFX extends Application
{
//define GUI components
private Label label;
private RadioButton rbRed, rbGreen, rbBlue;

public void start(Stage primaryStage)
{
	  //Step 1:initialize the relevant GUI components
    label = new Label("ASU CSE205 Programming");
    label.setFont(Font.font("SansSerif", 16));
    label.setTextFill(Color.RED);	//initial color

    //initialize each of the three radio buttons
    rbRed = new RadioButton("Red");
    rbGreen = new RadioButton("Green");
    rbBlue = new RadioButton("Blue");

    //Create a ToggleGroup so that the 3 radio buttons are
    //selected mutually exclusively; otherwise they are
    //indepedent of each other
    ToggleGroup group = new ToggleGroup();
	  rbRed.setToggleGroup(group);
	  rbGreen.setToggleGroup(group);
	  rbBlue.setToggleGroup(group);

	  //At beginning, let the red color radio button be selected
	  rbRed.setSelected(true);

	  //Creat a VBox that hold the 3 radio buttons
	  VBox rbPane = new VBox(20);
	  rbPane.getChildren().addAll(rbRed, rbGreen, rbBlue);

	 //set up the layout - use BorderPane
	 BorderPane pane = new BorderPane();
	 pane.setPadding(new Insets(12, 20, 12, 20));

	 //put radio button pane at left and label in center
   pane.setLeft(rbPane);
   pane.setCenter(label);

   //Step #3: Register each of the 3 radio buttons with a handler object
   rbRed.setOnAction(new ColorHandler());
   rbGreen.setOnAction(new ColorHandler());
   rbBlue.setOnAction(new ColorHandler());

   // Create a scene and place it in the stage
   Scene scene = new Scene(pane, 350, 150);
   primaryStage.setTitle("RadioButton Demo");
   primaryStage.setScene(scene); // Place the scene in the stage
   primaryStage.show(); // Display the stage
} //end start()

  //Step 2: Create a handler class that handle event from Radio buttons.
	//This class should implements the relevant interface
	private class ColorHandler implements EventHandler<ActionEvent>
	{
	    public void handle(ActionEvent e)
	    {
			//check which radio button is selected
	        if(rbRed.isSelected())
	        	label.setTextFill(Color.RED);
	        else if (rbGreen.isSelected())
	        	label.setTextFill(Color.GREEN);
	        else if (rbBlue.isSelected() == true)
	        	label.setTextFill(Color.BLUE);
	    }
  }//end of ColorHandler

  //only needed for certain IDE, such as Eclipse, etc.
  public static void main(String[] args)
  {
      launch(args);
  }

}//end of EventHandleRadioButton