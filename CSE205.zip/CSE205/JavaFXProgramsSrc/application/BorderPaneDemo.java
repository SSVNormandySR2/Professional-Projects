package application;

//This program demonstrate using of BorderPane
//BorderPane organize nodes in five area, top, bottom, left, right, and center

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.geometry.Insets;

public class BorderPaneDemo extends Application
{
public void start(Stage primaryStage)
{
  //Create a border pane
  BorderPane pane = new BorderPane();

  // Place nodes in the pane
  pane.setTop(new CustomPane("Top"));
  pane.setRight(new CustomPane("Right"));
  pane.setBottom(new CustomPane("Bottom"));
  pane.setLeft(new CustomPane("Left"));
  pane.setCenter(new CustomPane("Center"));

  // Create a scene and place it in the stage
  Scene scene = new Scene(pane, 200, 200);
  primaryStage.setTitle("BorderPaneDemo"); // Set the stage title
  primaryStage.setScene(scene); // Place the scene in the stage
  primaryStage.show(); // Display the stage
}
public static void main(String[] args)
{
launch(args);
}
}

//Define a custom pane to hold a label in the center of the pane
class CustomPane extends StackPane
{
public CustomPane(String title)
{
  this.getChildren().add(new Label(title));
  this.setStyle("-fx-border-color: black");	//CSS code used set the border color
  this.setPadding(new Insets(11, 12, 13, 14));
}
}