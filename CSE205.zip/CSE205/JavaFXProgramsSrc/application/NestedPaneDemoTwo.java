package application;

//This program demonstrate using of nested pane to set up the layout

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.TilePane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Orientation;

public class NestedPaneDemoTwo extends Application
{
public void start(Stage primaryStage)
{
  //Create a border pane as the root
  BorderPane rootPane = new BorderPane();

  //centerPane is a GridPane, it contains 3 labels and 3 text fields
  GridPane centerPane = new GridPane();
	centerPane.setAlignment(Pos.CENTER);
  centerPane.setPadding(new Insets(10, 10, 10, 10));
  centerPane.setHgap(5);
  centerPane.setVgap(10);

	//Create 3 labels
  Label fName = new Label("First Name:");
  Label mInitial = new Label("MI:");
  Label lName = new Label("Last Name:");

  //Create 3 text fields
  TextField fNameField = new TextField();
  TextField mInitField = new TextField();
  TextField lNameField = new TextField();

 	//add the 3 labels and 3 text fields accordingly
  centerPane.add(fName, 0, 0);
  centerPane.add(fNameField, 1, 0);
  centerPane.add(mInitial, 0, 1);
  centerPane.add(mInitField , 1, 1);
  centerPane.add(lName, 0, 2);
  centerPane.add(lNameField, 1, 2);

	//eastPane is a vertical TilePane, it contains 4 buttons
	TilePane eastPane = new TilePane(Orientation.VERTICAL);
	eastPane.setAlignment(Pos.CENTER);
  eastPane.setPadding(new Insets(10, 10, 10, 10));

 //create four buttons
  Button button1 = new Button("Add");
  Button button2 = new Button("Delete");
  Button button3 = new Button("Move Up");
  Button button4 = new Button("Move Down");

	//To enable the buttons to be resized to the size of the tile,
  button1.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
	button2.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
	button3.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
	button4.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

	//set the vertical gap between buttons
	eastPane.setVgap(10.0);
	eastPane.getChildren().addAll(button1,button2,button3,button4);

	//southPane is a horizontal TilePane, it contains 3 buttons
	TilePane southPane = new TilePane(Orientation.HORIZONTAL);
	southPane.setAlignment(Pos.CENTER);

  //create three buttons
  Button button5 = new Button("Apply");
  Button button6 = new Button("Continue");
  Button button7 = new Button("Exit");

	//To enable the buttons to be resized to the size of the tile,
  button5.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
	button6.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
	button7.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

	//set the horizontal gap between above 3 buttons
	southPane.setHgap(20.0);
	southPane.getChildren().addAll(button5,button6,button7);
  southPane.setPadding(new Insets(10, 10, 10, 10));

  //Place centerPane, eastPane and southPane inside the rootPane
  rootPane.setCenter(centerPane);
  rootPane.setRight(eastPane);
  rootPane.setBottom(southPane);

  // Create a scene and place it in the stage
  Scene scene = new Scene(rootPane, 350, 200);
  primaryStage.setTitle("Nest Pane Demo"); // Set the stage title
  primaryStage.setScene(scene); // Place the scene in the stage
  primaryStage.show(); // Display the stage
}
public static void main(String[] args)
{
	launch(args);
}
}