Vincent Latona
CSE 445
MW - 1:30

For this project, the XML files that are within the "XML Files" are deployed at the following URL:
https://www.public.asu.edu/~vlatona/[Filename]