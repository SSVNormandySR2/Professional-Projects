Group Names:
Amroger Singh
Vyome Khare
Vincent Latona

Notes:
All submitted files were sourced from Vincent Latona's
Virtual Machine.