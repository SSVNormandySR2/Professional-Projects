This submission counts for the group of Amroger Singh, Vyom Khare, and Vincent Latona.

Amroger Singh - 1211048836
Vyom Khare - 1216732348
Vincent Latona - 1216583771

The buffer design of our group was a circular array of a structure that has a process pointer
and an item number associated with it.