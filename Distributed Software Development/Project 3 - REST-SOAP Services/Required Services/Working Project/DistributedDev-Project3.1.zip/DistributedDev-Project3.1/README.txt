Vyom Khare
Vincent Latona

Work Contribution Breakdown
Vyom Khare - 50%
Vincent Latona - 50%

Services Implemented
Service 2 - Vincent Latona
Service 4 - Vincent Latona
Service 14 - Vyom Khare
Service 22 - Vyom Khare