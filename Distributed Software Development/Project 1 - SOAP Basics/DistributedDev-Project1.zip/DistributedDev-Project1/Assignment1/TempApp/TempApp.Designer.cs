﻿namespace TempApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tempDisplay = new System.Windows.Forms.Label();
            this.cToF = new System.Windows.Forms.Button();
            this.fToC = new System.Windows.Forms.Button();
            this.tempInput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tempDisplay
            // 
            this.tempDisplay.AutoSize = true;
            this.tempDisplay.Location = new System.Drawing.Point(122, 215);
            this.tempDisplay.Name = "tempDisplay";
            this.tempDisplay.Size = new System.Drawing.Size(168, 16);
            this.tempDisplay.TabIndex = 0;
            this.tempDisplay.Text = "Conversion displayed here";
            // 
            // cToF
            // 
            this.cToF.AutoSize = true;
            this.cToF.Location = new System.Drawing.Point(136, 119);
            this.cToF.Name = "cToF";
            this.cToF.Size = new System.Drawing.Size(143, 26);
            this.cToF.TabIndex = 1;
            this.cToF.Text = "Convert to Fahrenheit";
            this.cToF.UseVisualStyleBackColor = true;
            this.cToF.Click += new System.EventHandler(this.cToF_Click);
            // 
            // fToC
            // 
            this.fToC.AutoSize = true;
            this.fToC.Location = new System.Drawing.Point(136, 173);
            this.fToC.Name = "fToC";
            this.fToC.Size = new System.Drawing.Size(143, 26);
            this.fToC.TabIndex = 2;
            this.fToC.Text = "Convert to Celsius";
            this.fToC.UseVisualStyleBackColor = true;
            this.fToC.Click += new System.EventHandler(this.fToC_Click);
            // 
            // tempInput
            // 
            this.tempInput.AllowDrop = true;
            this.tempInput.Location = new System.Drawing.Point(136, 74);
            this.tempInput.Name = "tempInput";
            this.tempInput.Size = new System.Drawing.Size(143, 22);
            this.tempInput.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 301);
            this.Controls.Add(this.tempInput);
            this.Controls.Add(this.fToC);
            this.Controls.Add(this.cToF);
            this.Controls.Add(this.tempDisplay);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tempDisplay;
        private System.Windows.Forms.Button cToF;
        private System.Windows.Forms.Button fToC;
        private System.Windows.Forms.TextBox tempInput;
    }
}

