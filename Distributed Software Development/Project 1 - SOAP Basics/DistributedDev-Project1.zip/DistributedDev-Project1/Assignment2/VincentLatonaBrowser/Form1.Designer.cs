﻿namespace VincentLatonaBrowser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.url = new System.Windows.Forms.TextBox();
            this.search = new System.Windows.Forms.Button();
            this.operand1 = new System.Windows.Forms.TextBox();
            this.operand2 = new System.Windows.Forms.TextBox();
            this.plus = new System.Windows.Forms.Button();
            this.calcOutput = new System.Windows.Forms.Label();
            this.minus = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.quotePrompt = new System.Windows.Forms.Label();
            this.quoteInput = new System.Windows.Forms.TextBox();
            this.quoteDisplay = new System.Windows.Forms.Label();
            this.getQuote = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(1, 28);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(871, 383);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // url
            // 
            this.url.Location = new System.Drawing.Point(1, 0);
            this.url.Name = "url";
            this.url.Size = new System.Drawing.Size(737, 22);
            this.url.TabIndex = 1;
            this.url.Text = "http://";
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(744, 0);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(128, 23);
            this.search.TabIndex = 2;
            this.search.Text = "Go";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // operand1
            // 
            this.operand1.Location = new System.Drawing.Point(108, 421);
            this.operand1.Name = "operand1";
            this.operand1.Size = new System.Drawing.Size(100, 22);
            this.operand1.TabIndex = 3;
            // 
            // operand2
            // 
            this.operand2.Location = new System.Drawing.Point(225, 421);
            this.operand2.Name = "operand2";
            this.operand2.Size = new System.Drawing.Size(100, 22);
            this.operand2.TabIndex = 4;
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(108, 449);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(29, 23);
            this.plus.TabIndex = 5;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // calcOutput
            // 
            this.calcOutput.AutoSize = true;
            this.calcOutput.Location = new System.Drawing.Point(142, 486);
            this.calcOutput.Name = "calcOutput";
            this.calcOutput.Size = new System.Drawing.Size(147, 16);
            this.calcOutput.TabIndex = 6;
            this.calcOutput.Text = "Calculator Output: Here!";
            // 
            // minus
            // 
            this.minus.Location = new System.Drawing.Point(179, 449);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(29, 23);
            this.minus.TabIndex = 7;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // multiply
            // 
            this.multiply.Location = new System.Drawing.Point(225, 449);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(29, 23);
            this.multiply.TabIndex = 8;
            this.multiply.Text = "*";
            this.multiply.UseVisualStyleBackColor = true;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // divide
            // 
            this.divide.Location = new System.Drawing.Point(296, 449);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(29, 23);
            this.divide.TabIndex = 9;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = true;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // quotePrompt
            // 
            this.quotePrompt.AutoSize = true;
            this.quotePrompt.Location = new System.Drawing.Point(385, 422);
            this.quotePrompt.Name = "quotePrompt";
            this.quotePrompt.Size = new System.Drawing.Size(207, 16);
            this.quotePrompt.TabIndex = 16;
            this.quotePrompt.Text = "Enter a stock sybol to get a quote:";
            // 
            // quoteInput
            // 
            this.quoteInput.Location = new System.Drawing.Point(615, 419);
            this.quoteInput.Name = "quoteInput";
            this.quoteInput.Size = new System.Drawing.Size(148, 22);
            this.quoteInput.TabIndex = 17;
            // 
            // quoteDisplay
            // 
            this.quoteDisplay.AutoSize = true;
            this.quoteDisplay.Location = new System.Drawing.Point(402, 459);
            this.quoteDisplay.Name = "quoteDisplay";
            this.quoteDisplay.Size = new System.Drawing.Size(207, 16);
            this.quoteDisplay.TabIndex = 18;
            this.quoteDisplay.Text = "Quote information displayed here!";
            // 
            // getQuote
            // 
            this.getQuote.AutoSize = true;
            this.getQuote.Location = new System.Drawing.Point(769, 417);
            this.getQuote.Name = "getQuote";
            this.getQuote.Size = new System.Drawing.Size(91, 26);
            this.getQuote.TabIndex = 19;
            this.getQuote.Text = "Get a Quote!";
            this.getQuote.UseVisualStyleBackColor = true;
            this.getQuote.Click += new System.EventHandler(this.getQuote_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 530);
            this.Controls.Add(this.getQuote);
            this.Controls.Add(this.quoteDisplay);
            this.Controls.Add(this.quoteInput);
            this.Controls.Add(this.quotePrompt);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.calcOutput);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.operand2);
            this.Controls.Add(this.operand1);
            this.Controls.Add(this.search);
            this.Controls.Add(this.url);
            this.Controls.Add(this.webBrowser1);
            this.Name = "Form1";
            this.Text = "Vincent Latona\'s Browser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.TextBox url;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.TextBox operand1;
        private System.Windows.Forms.TextBox operand2;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Label calcOutput;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button divide;
        private System.Windows.Forms.Label quotePrompt;
        private System.Windows.Forms.TextBox quoteInput;
        private System.Windows.Forms.Label quoteDisplay;
        private System.Windows.Forms.Button getQuote;
    }
}

