﻿/*
 * Vincent Latona
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VincentLatonaBrowser
{
    public partial class Form1 : Form
    {
        private string verify = "";
        
        public Form1()
        {
            InitializeComponent();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
        }

        /*
         * This function handles the web browser navigation 
         */
        private void search_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(url.Text); //Navigate to given URL
        }

        /*
         * This function validates input format
         */
        private bool operandCheck()
        {
            try //Format check
            {
                double.Parse(operand1.Text);
                double.Parse(operand2.Text);
            }
            catch (FormatException) //Incorrect format
            {
                return false; //Return false for incorrect format
            }
            return true; //Return true to continue
        }

        /*
         * This function adds the given floating point numbers
         */
        private void plus_Click(object sender, EventArgs e)
        {
            if(operandCheck()) //Check input format
            {
                double op1 = double.Parse(operand1.Text); //Get operand1 value
                double op2 = double.Parse(operand2.Text); //Get operand2 value
                calcOutput.Text = "= " + (op1+op2); //Display result
            }
            else //Input format error
            {
                calcOutput.Text = "Please make sure each input is a floating point number!"; //Display error message
            }
        }

        /*
         * This function subtracts the given floating point numbers
         */
        private void minus_Click(object sender, EventArgs e)
        {
            if (operandCheck()) //Check input format
            {
                double op1 = double.Parse(operand1.Text); //Get operand1 value
                double op2 = double.Parse(operand2.Text); //Get operand2 value
                calcOutput.Text = "= " + (op1 - op2); //Display result
            }
            else //Input format error
            {
                calcOutput.Text = "Please make sure each input is a floating point number!"; //Display error message
            }
        }

        /*
         * This function multiplies the given floating point numbers
         */
        private void multiply_Click(object sender, EventArgs e)
        {
            if (operandCheck()) //Check input format
            {
                double op1 = double.Parse(operand1.Text); //Get operand1 value
                double op2 = double.Parse(operand2.Text); //Get operand2 value
                calcOutput.Text = "= " + (op1 * op2); //Display result
            }
            else //Input format error
            {
                calcOutput.Text = "Please make sure each input is a floating point number!"; //Display error message
            }
        }

        /*
         * This function divides the given floating point numbers
         */
        private void divide_Click(object sender, EventArgs e)
        {
            if (operandCheck()) //Check input format
            {
                double op1 = double.Parse(operand1.Text); //Get operand1 value
                double op2 = double.Parse(operand2.Text); //Get operand2 value
                if(op2 == 0) //Divides by 0 error
                {
                    calcOutput.Text = "Division by 0 Error!"; //Display error message
                }
                else //No division error
                {
                    calcOutput.Text = "= " + (op1 / op2); //Display result
                }
            }
            else //Input format error
            {
                calcOutput.Text = "Please make sure each input is a floating point number!"; //Display error message
            }
        }

        /*
         * This function calls the stock service to get a quote on a given company
         */
        private void getQuote_Click(object sender, EventArgs e)
        {
            StockQuote.ServiceClient broker = new StockQuote.ServiceClient(); //Instance of service caller
            quoteDisplay.Text = "Quote for " + quoteInput.Text + ": " + broker.getStockquote(quoteInput.Text); //Call broker and display quote
        }
    }
}
