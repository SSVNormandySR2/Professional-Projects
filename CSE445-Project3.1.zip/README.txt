Vyom Khare
Vincent Latona
CSE 445 - MW - 1:30 - 2:45

Work Contribution Breakdown
Vyom Khare - 50%
Vincent Latona - 50%

Services Implemented
Service 2 - Vincent Latona
Service 4 - Vincent Latona
Service 14 - Vyom Khare
Service 22 - Vyom Khare