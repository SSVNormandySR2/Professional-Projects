/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

import java.util.Scanner;

/*
 * This class defines the running function for the program
 */
public class PersonnelDirectory 
{
	/*
	 * This method runs the program
	 */
	public static void main(String[] args)
	{
		//Personnel data fields
		String first, middle, last = "";
		int empID = 0;
		int choice = -1; //Menu control
		Personnel per = new Personnel(); //Personnel management object
		Scanner scan = new Scanner(System.in); //Scanner object for user input
		
		boolean run = false; //Sentinel for program termination
		while(!run) //Run program
		{
			//Display program menu
			System.out.println("Welcome to the Personnel Directory Management System");
	        System.out.println("====================================================");
	        System.out.println("\n\n\t -1. Quit");
	        System.out.println("\n\t 1. Add Personnel");
	        System.out.println("\n\t 2. Find Personnel");
	        System.out.println("\n\t 3. Print Names");
	        System.out.println("\n\t 4. Number of Entries in the Directory");
	        System.out.println("\n\t Select one of the options above (-1, 1, 2, 3, 4)");
	        
	        choice = scan.nextInt(); //Get user input
	        scan.nextLine(); //Flush input buffer
	        
	        switch(choice) //Switch user input
	        {
	        	case -1: //Quit case
	        		run = true; //Set sentinel
	        		break;
	        	case 1: //Add personnel case
	        		System.out.println("Enter first name: "); //First name prompt
	        		first = scan.nextLine(); //Assign first name
	        		System.out.println("Enter last name: "); //Last name prompt
	        		last = scan.nextLine(); //Assign last name
	        		System.out.println("Enter middle name: "); //Middle name prompt
	        		middle = scan.nextLine(); //Assign middle name
	        		System.out.println("Enter employee id: ");
	        		empID = scan.nextInt(); //Assign employee ID
	        		scan.nextLine(); //Flush input buffer
	        		per.addPersonnel(first, last, middle, empID); //Add new personnel to list
	        		System.out.println(); //Newline
	        		break;
	        	case 2: //Find personnel case
	        		System.out.println("Enter first name: "); //First name prompt
	        		first = scan.nextLine(); //Assign first name
	        		System.out.println("Enter last name: "); //Last name prompt
	        		last = scan.nextLine(); //Assign last name
	        		per.find(first, last); //Search for person
	        		System.out.println(); //Newline
	        		break;
	        	case 3: //Print personnel case
	        		System.out.println("Enter the order 0: first, middle,  last, 1: first, last, middle, 2: last, first , middle ");
	  			  	int order = scan.nextInt();
	  			  	scan.nextLine(); //Flush input buffer
	  			  	if(order == 2) //Last, first, middle case
	  			  	{
	  			  		per.printLastFirstMiddle(); //Print last, first, middle
	  			  	}
	  			  	else if(order == 1) //First, last, middle case
	  			  	{
	  			  		per.printFirstLastMiddle(); //Print first, last, middle
	  			  	}
	  			  	else //First, middle, last case
	  			  	{
	  			  		per.printFirstMiddleLast(); //Print first, middle, last
	  			  	}
	  			  	System.out.println(); //Newline
	        		break;
	        	case 4: //Object count case
	        		System.out.println("Total Entries: " + per.getCount()); //Print total object count
	        		System.out.println(); //Newline
	        		break;
	        }
		}
		scan.close(); //Close scanner
	}
}
