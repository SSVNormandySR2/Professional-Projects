/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

import java.util.*;

/*
 * This class represents statistics of a list and provides methods to access them
 */
public class statistics 
{
	private double median;
	private double mean;
	private double variance;
	private double standardDeviation;
	private double sum;
	private double varianceSum;
	private int length;
	
	/*
	 * Constructor initializes values
	 */
	public statistics()
	{
		median = 0.0;
		mean = 0.0;
		variance = 0.0;
		standardDeviation = 0.0;
		sum = 0.0;
		varianceSum = 0.0;
		length = 0;
	}
	
	/*
	 * calculateStats will calculate median, mean, variance, and standard deviation of a given list
	 */
	public void calculateStats(ArrayList<Double> list)
	{
		Collections.sort(list); //Sort the list
		length = list.size(); //Set list size
		
		median = list.get(length / 2); //Set median value
		
		for(double num : list) //Iterate over list
		{
			sum += num; //Calculate sum
		}
		
		mean = sum / (double) length; //Set mean value
		
		for(double num : list) //Iterate over list
		{
			varianceSum += ((num - mean)*(num - mean)); //Calculate variance sum
		}
		
		variance = varianceSum / (double) (length - 1); //Set variance value
		
		standardDeviation = Math.sqrt(variance); //Set standard deviation value
	}
	
	/*
	 * toString defines the printing format
	 */
	public String toString()
	{
		String stats = "length: " + length + "\n"
				+ "mean: " + mean + "\n"
				+ "median: " + median + "\n"
				+ "variance: " + variance + "\n"
				+ "standard deviation: " + standardDeviation + "\n"; //String of statistics
		return stats;
	}
}
