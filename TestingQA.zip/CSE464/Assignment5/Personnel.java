/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

import java.util.*;

/*
 * This class manages a list of personnel
 */
public class Personnel 
{
	private ArrayList<Person> personnelList; //Personnel list
	
	/*
	 * This constructor initializes the data members
	 */
	public Personnel()
	{
		personnelList = new ArrayList<Person>(); //Initialize list
	}
	
	/*
	 * This method returns the number of objects in the personnel list
	 */
	public int getCount()
	{
		return personnelList.size(); //Return list size
	}
	
	/*
	 * This method adds an employee to the list
	 */
	public void addPersonnel(String first, String last, String middle, int empID)
	{
		Employee e = new Employee(first, last, middle, empID); //Create new employee
		personnelList.add(e); //Add new employee
	}
	
	/*
	 * This method searches the list for a given person
	 */
	public void find(String first, String last)
	{
		boolean found = false; //Success sentinel
		for(Person p : personnelList) //Iterate over personnel list
		{
			if(p.getFirst().equals(first) & p.getLast().equals(last)) //Found case
			{
				found = true; //Set sentinel
				System.out.println("Found"); //Print success message
				System.out.println(p.getFirst() + " " + p.getMiddle() + " " + p.getLast()); //Print found name
				return;
			}
		}
		if(!found) //No entry case
		{
			System.out.println("Not Found"); //Print failure message
			this.addPersonnel(first, last, " "); //Add new person to the list
		}
	}
	
	/*
	 * This method adds a person to the list
	 */
	private void addPersonnel(String first, String last, String middle)
	{
		Person p = new Person(first, last, middle); //Create new person
		personnelList.add(p); //Add new person
	}
	
	/*
	 * This method prints the names in first, middle, last order
	 */
	public void printFirstMiddleLast()
	{
		for(Person p : personnelList) //Iterate over the personnel list
		{
			System.out.println(p.getFirst() + " " + p.getMiddle() + " " + p.getLast()); //Print first, middle, last
		}
	}
	
	/*
	 * This method prints the names in first, last, middle order
	 */
	public void printFirstLastMiddle()
	{
		for(Person p : personnelList) //Iterate over personnel list
		{
			System.out.println(p.getFirst() + " " + p.getLast() + " " + p.getMiddle()); //Print first, last, middle
		}
	}
	
	/*
	 * This method prints the names in last, first, middle
	 */
	public void printLastFirstMiddle()
	{
		for(Person p : personnelList) //Iterate over personnel list
		{
			System.out.println(p.getLast() + " " + p.getFirst() + " " + p.getMiddle()); //Print last, first, middle
		}
	}
}
