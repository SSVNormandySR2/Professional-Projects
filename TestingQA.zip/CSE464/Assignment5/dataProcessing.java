/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.*;

/*
 * This class facilitates the UI of the program
 */
public class dataProcessing 
{
	public static void main(String[] args) throws FileNotFoundException
	{
		Scanner console = new Scanner(System.in); //Instantiate scanner object
		System.out.print("Input file: "); //Print input prompt
		String inputFileName = console.next(); //Take user input
		console.close(); //Close current scanner instance
		
		ArrayList<Double> data = new ArrayList<Double>(); //Define list for data
		
		File inputFile = new File(inputFileName); //Define file object to read from
		console = new Scanner(inputFile); //Set scanner to read from file object
		
		while(console.hasNextDouble()) //Iterate over input file
		{
			data.add(console.nextDouble()); //Add next double to list
		}
		
		console.close(); //Close scanner
		
		statistics dataStats = new statistics(); //Create statistics object
		dataStats.calculateStats(data); //Calculate statistics
		System.out.println(dataStats); //Print statistics
	}
}