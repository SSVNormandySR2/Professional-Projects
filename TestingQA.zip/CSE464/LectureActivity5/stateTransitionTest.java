/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class stateTransitionTest 
{
	private windshieldWiper wiperSystem; //Define wiper system to test
	
	@Test
	void offToInt1() 
	{
		wiperSystem = new windshieldWiper(0, "OFF", 1); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseLeverUp(); //Move lever up
			assertEquals(6, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(1, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(LeverErrorException e) //Exception case
		{
			fail("Lever error not expected."); //Fail test
		}
	}
	
	@Test
	void int1ToOff()
	{
		wiperSystem = new windshieldWiper(6, "INT", 1); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseLeverDown(); //Move lever down
			assertEquals(0, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("OFF", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(1, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(LeverErrorException e) //Exception case
		{
			fail("Lever error not expected."); //Fail test
		}
	}
	
	@Test
	void int1ToInt2()
	{
		wiperSystem = new windshieldWiper(6, "INT", 1); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseDialUp(); //Move dial up
			assertEquals(12, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(2, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(DialErrorException e) //Exception case
		{
			fail("Dial error not expected"); //Fail test
		}
	}
	
	@Test
	void int2ToInt1()
	{
		wiperSystem = new windshieldWiper(12, "INT", 2); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseDialDown(); //Move dial down
			assertEquals(6, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position;
			assertEquals(1, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(DialErrorException e) //Exception case
		{
			fail("Dial error not expected"); //Fail test
		}
	}
	
	@Test
	void int2ToInt3()
	{
		wiperSystem = new windshieldWiper(12, "INT", 2); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseDialUp(); //Move dial down
			assertEquals(20, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(DialErrorException e) //Exception case
		{
			fail("Dial error not expected"); //Fail test
		}
	}
	
	@Test
	void int3ToInt2()
	{
		wiperSystem = new windshieldWiper(20, "INT", 3); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseDialDown(); //Move dial down
			assertEquals(12, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(2, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(DialErrorException e) //Exception case
		{
			fail("Dial error not expected"); //Fail test
		}
	}
	
	@Test
	void int3ToLow()
	{
		wiperSystem = new windshieldWiper(20, "INT", 3); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseLeverUp(); //Move lever up
			assertEquals(30, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("LOW", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(LeverErrorException e) //Exception case
		{
			fail("Lever error not expected."); //Fail test
		}
	}
	
	@Test
	void lowToInt3()
	{
		wiperSystem = new windshieldWiper(30, "LOW", 3); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseLeverDown(); //Move lever down
			assertEquals(20, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("INT", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(3, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(LeverErrorException e) //Exception case
		{
			fail("Lever error not expected."); //Fail test
		}
	}
	
	@Test
	void lowToHigh()
	{
		wiperSystem = new windshieldWiper(30, "LOW", 1); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseLeverUp(); //Move lever up
			assertEquals(60, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("HIGH", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(1, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(LeverErrorException e) //Exception case
		{
			fail("Lever error not expected."); //Fail test
		}
	}
	
	@Test
	void highToLow()
	{
		wiperSystem = new windshieldWiper(60, "HIGH", 1); //Initialize speed, lever, and dial
		try
		{
			wiperSystem.senseLeverDown(); //Move lever down
			assertEquals(30, wiperSystem.getWiperSpeed()); //Verify wiper speed
			assertEquals("LOW", wiperSystem.getLeverPosition()); //Verify lever position
			assertEquals(1, wiperSystem.getDialPosition()); //Verify dial position
		}
		catch(LeverErrorException e) //Exception case
		{
			fail("Lever error not expected."); //Fail test
		}
	}
}
