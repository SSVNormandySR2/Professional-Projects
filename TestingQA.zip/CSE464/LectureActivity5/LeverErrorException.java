/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class represents a lever error
 */
public class LeverErrorException extends Exception 
{
	/*
	 * This constructor initializes the exception
	 */
	public LeverErrorException() 
	{
		super(); //Call exception constructor
	}
	
	/*
	 * This method triggers an exception
	 */
	public LeverErrorException(String error) 
	{
		super(error); //Call parent exception
	}
}