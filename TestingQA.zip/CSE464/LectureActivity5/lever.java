/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class represents the lever of the wiper system
 */
public class lever 
{
	private String leverPosition; //Position state variable
	
	/*
	 * This constructor initializes the position state
	 */
	public lever(String lev)
	{
		this.leverPosition = lev; //Set position state
	}
	
	/*
	 * This method returns the current position state
	 */
	public String getLeverPosition() 
	{
		return leverPosition; //Return position state
	}

	/*
	 * This method changes the position state
	 */
	public void setLeverPosition(String leverPosition) 
	{
		this.leverPosition = leverPosition; //Set position state
	}		
}