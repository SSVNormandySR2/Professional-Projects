/*
 * Vincent Latona
 * CSE 464 - TTH - 12:00
 */

/*
 * This class represents the dial of the wiper system
 */
public class dial 
{
	private int dialPosition; //Position state variable
	
	/*
	 * This constructor initalizes the position state
	 */
	public dial(int dPos)
	{
		this.dialPosition=dPos; //Set position state
	}
	
	/*
	 * This method returns current position state
	 */
	public int getDialPosition() 
	{
		return dialPosition; //Return position state
	}
	
	/*
	 * This method changes the position state
	 */
	public void setDialPosition(int dialPosition) 
	{
		this.dialPosition = dialPosition; //Set position state
	}
}