Vincent Latona
CSE 445 - MW - 1:30

This is the assignment 8 submission for Vincent Latona.

The individual components that were developed are listed in the accompanying component table.
They have also been deployed to the server for testing (Cisco VPN may be necessary to access server).
Please make sure to use the TA credentials in the project document to access and test the staff page.

In preparation for the assignment 9 integration, 
all member sevices have been integrated into the Members page in this assignment.