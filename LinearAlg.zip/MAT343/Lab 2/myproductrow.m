%myproductrow computes the product y = Ax in a row-wise fashion
function y = myproductrow(A,x)
[m,n] = size(A); %Evaluate size of matrix
[p,q] = size(x); %Evaluate size of vector

%Validate matrix/vector dimensions
if(q == 1 && n == p)
    y = zeros(m,1); %Create initial return vector
    
    %Iterate through each row to produce y
    for i = 1:m
        y(i) = A(i,:)*x; %Calculate each row of y
    end
    
else
    disp("Invalid dimensions"); %Display error message
    y = []; %Return empty matrix for invalid dimensions
end

end

