%rowproduct computes the matrix product of 2 matrices using rows
function C = rowproduct(A,B)
[m,n] = size(A); %Evaluate dimensions of A
[p,q] = size(B); %Evaluate dimensions of B

%Validate matrix dimensions
if(n == p)
    C = zeros(m,q); %Generate initial matrix for product
    
    %Iterate through each
    for i = 1:m
        C(i,:) = A(i,:)*B; %Populate the rows of C
    end
    
else
    disp("Invalid matrix dimensions"); %Display error message
    C = [];
end

end

