clf 
S=[0,1,1,0,0;0,0,1,1,0];
plot(S(1,:),S(2,:),'linewidth',2)
hold on 
D = [2, 0; 0, 3]; % dilation matrix 
DS = D*S; 
plot(DS(1,:),DS(2,:),'-r','linewidth',2) 
title('Example of Dilation')
legend('original square','dilated square','location','southeast')
grid on 
axis equal, axis([-1,4,-1,4]) % adjust the axis and the window 
hold off