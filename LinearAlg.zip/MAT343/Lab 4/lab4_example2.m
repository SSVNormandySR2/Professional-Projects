clear all;   % clear all variables 
clf;    % clear all settings for the plot 
S=[0,1,1,0,0;0,0,1,1,0]; 
plot(S(1,:),S(2,:),'linewidth',2);  % plot the square 
hold on; 
theta =pi/4; % define the angle theta 
Q=[cos(theta),-sin(theta);sin(theta),cos(theta)]; % rotation matrix 
QS=Q*S; % rotate the square 
plot(QS(1,:),QS(2,:),'-r','linewidth',2);   % plot the rotated square  
title('Example of Rotation');  % add a title 
legend('original square','rotated square') % add a legend 
axis equal; axis([-1,2,-1,2]); % set the window 
grid on; % add a grid 
hold off