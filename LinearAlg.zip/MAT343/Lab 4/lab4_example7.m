clf 
S=[0,1,1,0,0;0,0,1,1,0;1,1,1,1,1];    % square in homogeneous coordinates 
M=[1,0,4;0,1,-3;0,0,1];     % translation matrix 
MS=M*S;      % apply the translation to the square 
plot(S(1,:),S(2,:),'k','linewidth',2);  % plot the original square in black 
hold on 
plot(MS(1,:),MS(2,:),'r','linewidth',2);  % plot the translated square in red 
legend('original square','translated square','location','southwest');   
axis equal, axis([-1,6,-4,4]), grid on    % adjust the axis 
hold off