clf % clear all settings for the plot
S=[0 ,1 ,1 ,0 ,0;0 ,0 ,1 ,1 ,0];
p = plot (S(1 ,:) ,S (2 ,:)); % plot the square
axis ([ -2 ,2 , -2 ,2]) % set size of the graph
axis square , grid on % make the display square
hold on % hold the current graph

theta = pi/5; % define the angle theta 

%Counter-clockwise rotation
for i = 1:10
    Q=[cos(theta),-sin(theta);sin(theta),cos(theta)]; % rotation matrix 
    S = Q*S; % rotate the square
    set(p,'xdata',S(1 ,:) , 'ydata',S(2 ,:)); % erase original figure and plot
                                                 % the transformed figure
    pause (0.1) % adjust this pause rate to suit your computer .
end

%Clockwise rotation
for i = 1:10
    Q=[cos(-theta),-sin(-theta);sin(-theta),cos(-theta)]; % rotation matrix 
    S = Q*S; % contract the square
    set(p,'xdata',S(1 ,:) , 'ydata',S(2 ,:)); % erase original figure and plot
                                                 % the transformed figure
    pause (0.1) % adjust this pause rate to suit your computer .
end