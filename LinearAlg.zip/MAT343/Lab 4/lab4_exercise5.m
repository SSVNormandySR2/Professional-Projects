clf 
S=[0,1,1,0,0;0,0,1,1,0;1,1,1,1,1];    % square in homogeneous coordinates 
M=[1,0,4;0,1,-3;0,0,1];     % translation matrix 
MS=M*S;      % apply the translation to the square 
plot(MS(1,:),MS(2,:),'k','linewidth',2);  % plot the original square in black 
hold on 
R = [0,1,0;1,0,0;0,0,1];
RMS = R*MS;
plot(RMS(1,:),RMS(2,:),'r','linewidth',2);  % plot the translated square in red 
plot([-4,6], [-4,6]); %plot the line x=y
legend('translated square','reflected square','line y = x','location', 'southwest');   
axis equal, axis([-4,6,-4,6]), grid on    % adjust the axis 
hold off