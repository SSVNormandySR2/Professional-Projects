clf 
S=[0,1,1,0,0;0,0,1,1,0]; 
plot(S(1,:),S(2,:),'linewidth',2) 
hold on 
T=[1,4;0,1];    % shear transformation matrix 
theta =pi/4; % define the angle theta 
Q=[cos(theta),-sin(theta);sin(theta),cos(theta)]; % rotation matrix 
QTS=Q*T*S;
plot(QTS(1,:),QTS(2,:),'-r','linewidth',2);
title('Exercise 2: Counterclockwise Rotation of Horizontal Shear')
legend('original square','transformed square') 
axis equal,axis([-1,6,-1,6]); grid on   %adjust the axis and the window 
hold off