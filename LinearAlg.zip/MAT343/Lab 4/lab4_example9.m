clf 
S=[0,1,1,0,0;0,0,1,1,0;1,1,1,1,1]; % square in homogeneous coordinates 
M1 = [1,0,0.4;0,1,0;0,0,1]; % first translation matrix 
theta = pi/6;  % define the angle theta 
Q=[cos(theta),-sin(theta),0;sin(theta),cos(theta),0;0,0,1]; % rotation matrix about (0,0)
QP=[1,0,9;0,1,0;0,0,1]*Q'*[1,0,-9;0,1,0;0,0,1];   % rotation matrix about (9,0)
p = plot(S(1,:),S(2,:)); % plot the original square
axis equal, axis([-0.5,11,-2,5]), grid on
for i = 1:20
    S = M1*S; % compute the translated square 
    set(p,'xdata',S(1,:),'ydata',S(2,:)); % plot the translated square 
    pause(0.1) 
end 
for i = 1:3
    S=QP*S; % compute the rotated square 
    set(p,'xdata',S(1,:),'ydata',S(2,:)); % plot the rotated square 
    pause(0.1) 
end