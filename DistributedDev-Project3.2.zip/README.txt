Vyom Khare
Vincent Latona
CSE 445 - MW - 1:30 - 2:45

Work Contribution Breakdown
Vyom Khare - 50%
Vincent Latona - 50%

Services Implemented
Easy RESTful - WordCount - Vincent Latona
Easy RESTful - CharacterCount - Vincent Latona
Easy WSDL - SpecialCharacterCount - Vincent Latona
Easy WSDL - CountOccurrences - Vincent Latona
Easy RESTful - replaceCharacters - Vyom Khare
Easy RESTful - replaceWords - Vyom Khare
Easy WSDL - deleteCharacter - Vyom Khare
Easy WSDL - deleteWord - Vyom Khare