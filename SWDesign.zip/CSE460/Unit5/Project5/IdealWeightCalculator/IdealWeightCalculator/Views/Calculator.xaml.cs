/*
 * Vincent Latona
 * CSE 460 - MW - 4:30
 */

using System.Runtime.CompilerServices;

namespace IdealWeightCalculator.Views;

public partial class Calculator : ContentPage
{
	public Calculator()
	{
		InitializeComponent();
		BindingContext = new IdealWeightCalculator.ViewModels.CalcViewModel(); //Bind to VM
	}
}