/*
 * Vincent Latona
 * CSE 460 - MW - 4:30
 */

namespace IdealWeightCalculator.Views;

public partial class API : ContentPage
{
	public API()
	{
		InitializeComponent();
		BindingContext = new IdealWeightCalculator.ViewModels.APIViewModel(); //Bind to VM
	}
}