﻿namespace IdealWeightCalculator;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
