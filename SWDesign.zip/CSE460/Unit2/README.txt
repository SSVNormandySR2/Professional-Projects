Vincent Latona
CSE460 - MW - 4:30

As per Dr. De Luca's announcement, I have condensed several identified objects into 
functionalities of the ConcussionAssessmentSystem class for use as a simple console
application.